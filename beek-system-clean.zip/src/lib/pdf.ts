import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import type { DailyReport } from "./types";
import { EXPENSE_CATEGORIES } from "./types";
import { computeSummary, formatMoney } from "./calc";

// Arabic glyph shaping/RTL in jsPDF's default fonts is unreliable, so the PDF export
// renders labels transliterated as plain reference tables (numbers stay exact and legible).
// For a pixel-perfect Arabic PDF, use the in-app "Print" button instead (browser print-to-PDF
// renders the real RTL Tajawal layout via CSS, and needs no extra fonts).

export function exportReportToPdf(report: DailyReport) {
  const doc = new jsPDF();
  const summary = computeSummary(report.data);

  doc.setFontSize(14);
  doc.text(`Daily Closing Report - ${report.date} (${report.dayName})`, 14, 16);
  doc.setFontSize(10);
  doc.text(`Cashier: ${report.cashierName}   Branch: ${report.branch}`, 14, 23);

  const overviewRows = [
    ["Opening Cash", formatMoney(report.data.openingCash)],
    ["Sales", formatMoney(report.data.sales)],
    ["Other Sales", formatMoney(report.data.otherSales)],
    ["Visa POS", formatMoney(report.data.visaPOS)],
    ["Wallet POS", formatMoney(report.data.walletPOS)],
    ["RT POS", formatMoney(report.data.rtPOS)],
    ["Maestro POS", formatMoney(report.data.maestroPOS)],
    ["Actual Cash in Drawer", formatMoney(report.data.actualCashInDrawer)]
  ];
  autoTable(doc, { startY: 28, head: [["Overview", "Amount"]], body: overviewRows, theme: "grid" });

  let y = (doc as any).lastAutoTable.finalY + 6;
  for (const cat of EXPENSE_CATEGORIES) {
    const items = report.data[cat.key];
    if (!items.length) continue;
    autoTable(doc, {
      startY: y,
      head: [[cat.key, "Amount", "Notes"]],
      body: items.map((i) => [i.name, formatMoney(i.amount), i.notes ?? ""]),
      theme: "striped",
      styles: { fontSize: 8 }
    });
    y = (doc as any).lastAutoTable.finalY + 6;
    if (y > 260) {
      doc.addPage();
      y = 16;
    }
  }

  autoTable(doc, {
    startY: y,
    head: [["Summary", "Amount"]],
    body: [
      ["Total Expenses", formatMoney(summary.totalExpenses)],
      ["Total POS", formatMoney(summary.totalPOS)],
      ["Expected Cash", formatMoney(summary.expectedCash)],
      ["Actual Cash", formatMoney(summary.totalCashAvailable)],
      ["Difference", formatMoney(summary.difference)]
    ],
    theme: "grid"
  });

  doc.save(`closing-${report.date}.pdf`);
}

/** Opens the browser print dialog against the on-screen Arabic RTL layout - "print to PDF" gives a true Arabic PDF. */
export function printReport() {
  window.print();
}
