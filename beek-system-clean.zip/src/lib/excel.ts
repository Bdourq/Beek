import * as XLSX from "xlsx";
import type { DailyReport, ExpenseItem } from "./types";
import { newId } from "./types";
import { EXPENSE_CATEGORIES } from "./types";
import { computeSummary } from "./calc";

/** Reads an .xlsx file expecting columns: name/الاسم | amount/المبلغ | notes/ملاحظات (any order, Arabic or English headers). */
export async function importExpensesFromExcel(file: File): Promise<ExpenseItem[]> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "" });

  const pick = (row: Record<string, unknown>, keys: string[]) => {
    for (const k of keys) {
      const found = Object.keys(row).find((h) => h.trim().toLowerCase() === k);
      if (found !== undefined && row[found] !== "") return row[found];
    }
    return undefined;
  };

  return rows
    .map((row) => {
      const name = pick(row, ["name", "الاسم", "البند", "item"]);
      const amount = pick(row, ["amount", "المبلغ", "القيمة"]);
      const notes = pick(row, ["notes", "ملاحظات", "note"]);
      if (name === undefined || amount === undefined) return null;
      return {
        id: newId("exp"),
        name: String(name),
        amount: Number(amount) || 0,
        notes: notes ? String(notes) : undefined
      } satisfies ExpenseItem;
    })
    .filter((x): x is ExpenseItem => x !== null);
}

/** Exports the full report (all categories + employees + summary) as a multi-section .xlsx file. */
export function exportReportToExcel(report: DailyReport) {
  const wb = XLSX.utils.book_new();

  const overview = [
    ["التاريخ", report.date],
    ["اليوم", report.dayName],
    ["الكاشير", report.cashierName],
    ["الفرع", report.branch],
    ["رصيد افتتاحي", report.data.openingCash],
    ["المبيعات", report.data.sales],
    ["مبيعات أخرى", report.data.otherSales],
    ["فيزا", report.data.visaPOS],
    ["محفظة", report.data.walletPOS],
    ["RT", report.data.rtPOS],
    ["مايسترو", report.data.maestroPOS],
    ["النقدية الفعلية بالدرج", report.data.actualCashInDrawer]
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(overview), "نظرة عامة");

  for (const cat of EXPENSE_CATEGORIES) {
    const items = report.data[cat.key];
    if (!items.length) continue;
    const aoa = [["البند", "المبلغ", "ملاحظات"], ...items.map((i) => [i.name, i.amount, i.notes ?? ""])];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa), cat.label.slice(0, 31));
  }

  if (report.data.employees.length) {
    const aoa = [
      ["#", "الاسم", "دخول", "خروج", "ساعات", "أجر الساعة", "الإجمالي", "السلفة", "موقّع"],
      ...report.data.employees.map((e) => [
        e.number,
        e.name,
        e.shiftIn,
        e.shiftOut,
        e.workedHours ?? "",
        e.hourlyRate ?? "",
        e.wageTotal ?? "",
        e.advance,
        e.signed ? "نعم" : "لا"
      ])
    ];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa), "الموظفون");
  }

  const summary = computeSummary(report.data);
  const summaryAoa = [
    ["البند", "المبلغ"],
    ...summary.rows.map((r) => [r.label, r.amount]),
    ["إجمالي المصاريف", summary.totalExpenses],
    ["إجمالي أجهزة الدفع", summary.totalPOS],
    ["النقدية المتوقعة", summary.expectedCash],
    ["النقدية الفعلية", summary.totalCashAvailable],
    ["الفرق", summary.difference]
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(summaryAoa), "الملخص");

  XLSX.writeFile(wb, `اغلاق-${report.date}.xlsx`);
}
