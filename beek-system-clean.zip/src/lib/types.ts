export interface ExpenseItem {
  id: string;
  name: string;
  amount: number;
  notes?: string;
}

export interface VendorDebt {
  id: string;
  vendorName: string;
  amount: number;
  notes?: string;
}

export interface CustodyEntry {
  id: string;
  description: string;
  credit: number;
  debit: number;
}

export interface EmployeeRecord {
  id: string;
  number: number;
  name: string;
  advance: number;
  hourlyRate?: number;
  workedHours?: number;
  wageTotal?: number;
  shiftIn: string;
  shiftOut: string;
  signed: boolean;
}

/** The expense-category keys that behave the same way in the UI (name + amount + notes). */
export const EXPENSE_CATEGORIES = [
  { key: "newDebts", label: "ديون جديدة" },
  { key: "purchases", label: "مشتريات" },
  { key: "adminExpenses", label: "مصاريف إدارية" },
  { key: "apartmentExpenses", label: "مصاريف الشقة" },
  { key: "maintenance", label: "صيانة" },
  { key: "spices", label: "بهارات" },
  { key: "yahyaAccount", label: "حساب يحيى" },
  { key: "abuAbdullahAccount", label: "حساب أبو عبدالله" },
  { key: "walletExpenses", label: "مصاريف المحفظة" },
  { key: "otherExpenses", label: "مصاريف أخرى" }
] as const;

export type ExpenseCategoryKey = (typeof EXPENSE_CATEGORIES)[number]["key"];

export interface ReportData {
  openingCash: number;
  sales: number;
  otherSales: number;
  newDebtsTotal: number;
  oldDebtsPaidTotal: number;
  newDebts: ExpenseItem[];
  custodies: CustodyEntry[];
  purchases: ExpenseItem[];
  vendorDebtsPaid: VendorDebt[];
  adminExpenses: ExpenseItem[];
  apartmentExpenses: ExpenseItem[];
  maintenance: ExpenseItem[];
  spices: ExpenseItem[];
  yahyaAccount: ExpenseItem[];
  abuAbdullahAccount: ExpenseItem[];
  walletExpenses: ExpenseItem[];
  otherExpenses: ExpenseItem[];
  employees: EmployeeRecord[];
  actualCashInDrawer: number;
  visaPOS: number;
  walletPOS: number;
  rtPOS: number;
  maestroPOS: number;
  priceDiff: number;
  generalNotes: string;
}

export type ClosingType = "daily" | "shift" | "custody";
export type ReportStatus = "open" | "closed";

export interface DailyReport {
  id: string;
  date: string; // YYYY-MM-DD
  dayName: string;
  cashierName: string;
  branch: string;
  closingType: ClosingType;
  status: ReportStatus;
  data: ReportData;
  createdAt: string;
  updatedAt: string;
}

export function emptyReportData(): ReportData {
  return {
    openingCash: 0,
    sales: 0,
    otherSales: 0,
    newDebtsTotal: 0,
    oldDebtsPaidTotal: 0,
    newDebts: [],
    custodies: [],
    purchases: [],
    vendorDebtsPaid: [],
    adminExpenses: [],
    apartmentExpenses: [],
    maintenance: [],
    spices: [],
    yahyaAccount: [],
    abuAbdullahAccount: [],
    walletExpenses: [],
    otherExpenses: [],
    employees: [],
    actualCashInDrawer: 0,
    visaPOS: 0,
    walletPOS: 0,
    rtPOS: 0,
    maestroPOS: 0,
    priceDiff: 0,
    generalNotes: ""
  };
}

const ARABIC_DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];

export function arabicDayName(dateStr: string): string {
  const d = new Date(dateStr + "T00:00:00");
  return ARABIC_DAYS[d.getDay()];
}

export function todayStr(): string {
  const d = new Date();
  const tz = d.getTimezoneOffset();
  const local = new Date(d.getTime() - tz * 60000);
  return local.toISOString().slice(0, 10);
}

export function newId(prefix = "id"): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
