import { get, set, del, keys, createStore } from "idb-keyval";
import type { DailyReport } from "./types";

const REPORT_PREFIX = "report:";
const LS_INDEX_KEY = "yb_reports_index_v1";

let store: ReturnType<typeof createStore> | null = null;
let idbAvailable = true;

function getStore() {
  if (!store) store = createStore("yahya-albaik-closing", "reports");
  return store;
}

/** Detects whether IndexedDB actually works in this browser (private mode / Safari can throw). */
async function checkIdb(): Promise<boolean> {
  try {
    await set("__probe__", 1, getStore());
    await del("__probe__", getStore());
    return true;
  } catch {
    return false;
  }
}

function lsIndex(): string[] {
  try {
    return JSON.parse(localStorage.getItem(LS_INDEX_KEY) || "[]");
  } catch {
    return [];
  }
}

function lsSaveIndex(ids: string[]) {
  localStorage.setItem(LS_INDEX_KEY, JSON.stringify(Array.from(new Set(ids))));
}

let readyPromise: Promise<void> | null = null;
export function ready(): Promise<void> {
  if (!readyPromise) {
    readyPromise = checkIdb().then((ok) => {
      idbAvailable = ok;
    });
  }
  return readyPromise;
}

/** Always mirrors writes to localStorage too, so a report already open survives an IDB hiccup. */
export async function saveReport(report: DailyReport): Promise<void> {
  await ready();
  const key = REPORT_PREFIX + report.id;
  try {
    localStorage.setItem(key, JSON.stringify(report));
    const idx = lsIndex();
    if (!idx.includes(report.id)) lsSaveIndex([...idx, report.id]);
  } catch {
    // localStorage full/unavailable - IDB is still the source of truth if available
  }
  if (idbAvailable) {
    await set(report.id, report, getStore());
  }
}

export async function deleteReport(id: string): Promise<void> {
  await ready();
  try {
    localStorage.removeItem(REPORT_PREFIX + id);
    lsSaveIndex(lsIndex().filter((x) => x !== id));
  } catch {
    /* ignore */
  }
  if (idbAvailable) await del(id, getStore());
}

export async function getReport(id: string): Promise<DailyReport | undefined> {
  await ready();
  if (idbAvailable) {
    const fromIdb = await get<DailyReport>(id, getStore());
    if (fromIdb) return fromIdb;
  }
  try {
    const raw = localStorage.getItem(REPORT_PREFIX + id);
    return raw ? JSON.parse(raw) : undefined;
  } catch {
    return undefined;
  }
}

export async function listReports(): Promise<DailyReport[]> {
  await ready();
  const results = new Map<string, DailyReport>();

  if (idbAvailable) {
    const idbKeys = await keys(getStore());
    for (const k of idbKeys) {
      const r = await get<DailyReport>(k as string, getStore());
      if (r) results.set(r.id, r);
    }
  }

  for (const id of lsIndex()) {
    if (results.has(id)) continue;
    try {
      const raw = localStorage.getItem(REPORT_PREFIX + id);
      if (raw) results.set(id, JSON.parse(raw));
    } catch {
      /* ignore corrupted entry */
    }
  }

  return Array.from(results.values()).sort((a, b) => (a.date < b.date ? 1 : -1));
}

export async function getReportByDate(date: string): Promise<DailyReport | undefined> {
  const all = await listReports();
  return all.find((r) => r.date === date);
}
