import { EXPENSE_CATEGORIES, type ReportData } from "./types";

export interface SummaryRow {
  key: string;
  label: string;
  amount: number;
}

export type DifferenceType = "balanced" | "shortage" | "surplus";

export interface Summary {
  rows: SummaryRow[];
  totalExpenses: number;
  totalPOS: number;
  expectedCash: number;
  totalCashAvailable: number;
  difference: number;
  differenceType: DifferenceType;
}

const sum = (items: { amount: number }[]) => items.reduce((t, i) => t + (Number(i.amount) || 0), 0);

/**
 * expectedCash = opening + sales + otherSales + oldDebtsPaidTotal
 *              - (all expense categories) - vendorDebtsPaid - newDebtsTotal - POS totals
 * The drawer should hold cash only; card/wallet/RT/Maestro sales are deducted since
 * that money never physically sits in the drawer.
 */
export function computeSummary(data: ReportData): Summary {
  const rows: SummaryRow[] = [];

  for (const cat of EXPENSE_CATEGORIES) {
    const amount = sum(data[cat.key] as { amount: number }[]);
    if (amount !== 0) rows.push({ key: cat.key, label: cat.label, amount });
  }

  const vendorDebtsPaid = sum(data.vendorDebtsPaid);
  if (vendorDebtsPaid) rows.push({ key: "vendorDebtsPaid", label: "ديون موردين مسددة", amount: vendorDebtsPaid });

  const custodyNet = data.custodies.reduce((t, c) => t + (Number(c.credit) || 0) - (Number(c.debit) || 0), 0);

  const totalExpenses = rows.reduce((t, r) => t + r.amount, 0);
  const totalPOS = data.visaPOS + data.walletPOS + data.rtPOS + data.maestroPOS;

  const expectedCash =
    data.openingCash +
    data.sales +
    data.otherSales +
    data.oldDebtsPaidTotal +
    custodyNet -
    totalExpenses -
    data.newDebtsTotal -
    totalPOS +
    data.priceDiff;

  const totalCashAvailable = data.actualCashInDrawer;
  const difference = Math.round((totalCashAvailable - expectedCash) * 100) / 100;

  return {
    rows,
    totalExpenses,
    totalPOS,
    expectedCash: Math.round(expectedCash * 100) / 100,
    totalCashAvailable,
    difference,
    differenceType: difference === 0 ? "balanced" : difference > 0 ? "surplus" : "shortage"
  };
}

export function formatMoney(n: number): string {
  const v = Number.isFinite(n) ? n : 0;
  return v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function totalWages(data: ReportData): number {
  return data.employees.reduce((t, e) => t + (Number(e.wageTotal) || 0) - (Number(e.advance) || 0), 0);
}
