import { useState } from "react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Delete } from "lucide-react";

interface NumericKeypadProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialValue?: number;
  label?: string;
  onConfirm: (value: number) => void;
}

const KEYS = ["7", "8", "9", "4", "5", "6", "1", "2", "3", ".", "0", "back"] as const;

export function NumericKeypad({ open, onOpenChange, initialValue = 0, label, onConfirm }: NumericKeypadProps) {
  const [value, setValue] = useState(initialValue ? String(initialValue) : "");

  function press(key: (typeof KEYS)[number]) {
    if (key === "back") {
      setValue((v) => v.slice(0, -1));
      return;
    }
    if (key === "." && value.includes(".")) return;
    setValue((v) => (v === "0" ? key : v + key));
  }

  function confirm() {
    onConfirm(Number(value) || 0);
    onOpenChange(false);
    setValue("");
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent onOpenAutoFocus={(e) => e.preventDefault()}>
        <DialogTitle className="mb-2 text-center text-xs text-zinc-400">{label ?? "أدخل المبلغ"}</DialogTitle>
        <div className="num mb-4 rounded-xl bg-surface-300/60 p-4 text-left text-3xl font-bold text-accent">
          {value || "0"}
        </div>
        <div className="grid grid-cols-3 gap-2">
          {KEYS.map((k) => (
            <Button
              key={k}
              variant="outline"
              className="h-14 text-xl"
              onClick={() => press(k)}
              type="button"
            >
              {k === "back" ? <Delete className="h-5 w-5" /> : k}
            </Button>
          ))}
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)} type="button">
            إلغاء
          </Button>
          <Button
            onClick={confirm}
            type="button"
            onKeyDown={(e) => e.key === "Enter" && confirm()}
          >
            تأكيد (Enter)
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
