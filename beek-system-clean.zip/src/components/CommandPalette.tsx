import { useMemo, useState } from "react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useDebounce } from "@/hooks/useDebounce";
import type { DailyReport } from "@/lib/types";
import { formatMoney } from "@/lib/calc";
import { computeSummary } from "@/lib/calc";
import { Search } from "lucide-react";

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reports: DailyReport[];
  onSelect: (date: string) => void;
}

export function CommandPalette({ open, onOpenChange, reports, onSelect }: CommandPaletteProps) {
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebounce(query, 150);

  const results = useMemo(() => {
    const q = debouncedQuery.trim().toLowerCase();
    if (!q) return reports.slice(0, 8);
    return reports
      .filter((r) => r.date.includes(q) || r.cashierName.toLowerCase().includes(q) || r.branch.toLowerCase().includes(q))
      .slice(0, 20);
  }, [debouncedQuery, reports]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogTitle className="sr-only">بحث في الإغلاقات</DialogTitle>
        <div className="flex items-center gap-2 rounded-lg border border-white/10 bg-surface-300/60 px-3">
          <Search className="h-4 w-4 text-zinc-500" />
          <Input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث بالتاريخ، الكاشير، أو الفرع..."
            className="h-11 border-none bg-transparent px-0 focus:ring-0"
          />
        </div>
        <div className="mt-3 max-h-80 space-y-1 overflow-y-auto">
          {results.length === 0 && <p className="p-4 text-center text-sm text-zinc-500">لا توجد نتائج</p>}
          {results.map((r) => {
            const s = computeSummary(r.data);
            return (
              <button
                key={r.id}
                onClick={() => {
                  onSelect(r.date);
                  onOpenChange(false);
                }}
                type="button"
                className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-right hover:bg-white/5"
              >
                <div>
                  <div className="num text-sm font-bold text-zinc-100">{r.date}</div>
                  <div className="text-xs text-zinc-500">
                    {r.dayName} · {r.cashierName} · {r.branch}
                  </div>
                </div>
                <div className={"num text-xs font-bold " + (s.difference === 0 ? "text-emerald-400" : s.difference < 0 ? "text-red-400" : "text-amber-400")}>
                  {formatMoney(s.difference)}
                </div>
              </button>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}
