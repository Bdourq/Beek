import { forwardRef, useImperativeHandle, useRef, useState } from "react";
import { Trash2, Calculator } from "lucide-react";
import type { ExpenseItem } from "@/lib/types";
import { newId } from "@/lib/types";
import { formatMoney } from "@/lib/calc";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { NumericKeypad } from "@/components/NumericKeypad";

interface ExpenseTableProps {
  label: string;
  items: ExpenseItem[];
  onChange: (items: ExpenseItem[]) => void;
  /** true on touch/small screens - swaps the amount input for the big numeric keypad */
  useKeypad?: boolean;
}

export interface ExpenseTableHandle {
  focusNewRow: () => void;
}

export const ExpenseTable = forwardRef<ExpenseTableHandle, ExpenseTableProps>(function ExpenseTable(
  { label, items, onChange, useKeypad = false },
  ref
) {
  const [draftName, setDraftName] = useState("");
  const [draftAmount, setDraftAmount] = useState("");
  const [draftNotes, setDraftNotes] = useState("");
  const [keypadOpen, setKeypadOpen] = useState(false);
  const nameRef = useRef<HTMLInputElement>(null);
  const amountRef = useRef<HTMLInputElement>(null);

  useImperativeHandle(ref, () => ({
    focusNewRow: () => nameRef.current?.focus()
  }));

  function commitRow(amountOverride?: number) {
    if (!draftName.trim()) {
      nameRef.current?.focus();
      return;
    }
    const item: ExpenseItem = {
      id: newId("exp"),
      name: draftName.trim(),
      amount: amountOverride ?? Number(draftAmount) || 0,
      notes: draftNotes.trim() || undefined
    };
    onChange([...items, item]);
    setDraftName("");
    setDraftAmount("");
    setDraftNotes("");
    // auto-focus flow: jump straight back to the name field for the next entry
    requestAnimationFrame(() => nameRef.current?.focus());
  }

  function removeRow(id: string) {
    onChange(items.filter((i) => i.id !== id));
  }

  function updateRow(id: string, patch: Partial<ExpenseItem>) {
    onChange(items.map((i) => (i.id === id ? { ...i, ...patch } : i)));
  }

  const total = items.reduce((t, i) => t + (Number(i.amount) || 0), 0);

  return (
    <div className="rounded-xl border border-white/5 bg-surface-200/40">
      <div className="flex items-center justify-between border-b border-white/5 px-3 py-2">
        <span className="text-xs font-bold text-zinc-300">{label}</span>
        <span className="num text-xs font-bold text-accent">{formatMoney(total)}</span>
      </div>

      {items.length > 0 && (
        <div className="divide-y divide-white/5">
          {items.map((item) => (
            <div key={item.id} className="grid grid-cols-[1fr_100px_1fr_32px] gap-2 px-3 py-1.5 items-center">
              <input
                className="h-8 rounded-md bg-transparent px-2 text-sm text-zinc-200 outline-none focus:bg-surface-300/60"
                value={item.name}
                onChange={(e) => updateRow(item.id, { name: e.target.value })}
              />
              <input
                className="num h-8 rounded-md bg-transparent px-2 text-sm text-accent outline-none focus:bg-surface-300/60"
                value={item.amount}
                inputMode="decimal"
                onChange={(e) => updateRow(item.id, { amount: Number(e.target.value) || 0 })}
              />
              <input
                className="h-8 rounded-md bg-transparent px-2 text-xs text-zinc-500 outline-none focus:bg-surface-300/60"
                value={item.notes ?? ""}
                placeholder="ملاحظات"
                onChange={(e) => updateRow(item.id, { notes: e.target.value })}
              />
              <button
                onClick={() => removeRow(item.id)}
                className="flex h-8 w-8 items-center justify-center rounded-md text-zinc-500 hover:bg-red-500/10 hover:text-red-400"
                aria-label="حذف"
                type="button"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* draft / speed-entry row */}
      <div className="grid grid-cols-[1fr_100px_1fr_32px] gap-2 border-t border-dashed border-white/10 px-3 py-2 items-center">
        <Input
          ref={nameRef}
          value={draftName}
          placeholder="اسم البند (أو مسح باركود)"
          className="h-8 text-sm"
          onChange={(e) => setDraftName(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              if (useKeypad) setKeypadOpen(true);
              else amountRef.current?.focus();
            }
          }}
        />
        {useKeypad ? (
          <button
            type="button"
            onClick={() => setKeypadOpen(true)}
            className="num flex h-8 items-center justify-center gap-1 rounded-md border border-white/10 bg-surface-300/60 px-2 text-sm text-accent"
          >
            <Calculator className="h-3.5 w-3.5" />
            {draftAmount || "0"}
          </button>
        ) : (
          <Input
            ref={amountRef}
            value={draftAmount}
            inputMode="decimal"
            placeholder="0.00"
            className="num h-8 text-sm"
            onChange={(e) => setDraftAmount(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                commitRow();
              }
            }}
          />
        )}
        <Input
          value={draftNotes}
          placeholder="ملاحظات"
          className="h-8 text-xs"
          onChange={(e) => setDraftNotes(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && commitRow()}
        />
        <Button size="icon" variant="ghost" onClick={commitRow} type="button" className="h-8 w-8 text-accent">
          +
        </Button>
      </div>

      <NumericKeypad
        open={keypadOpen}
        onOpenChange={setKeypadOpen}
        label={`مبلغ: ${draftName || label}`}
        onConfirm={(v) => commitRow(v)}
      />
    </div>
  );
});
