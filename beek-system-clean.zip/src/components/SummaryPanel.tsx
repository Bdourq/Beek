import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { computeSummary, formatMoney } from "@/lib/calc";
import type { ReportData } from "@/lib/types";
import { cn } from "@/lib/utils";
import { AlertTriangle, CheckCircle2, TrendingUp } from "lucide-react";

export function SummaryPanel({ data }: { data: ReportData }) {
  const s = computeSummary(data);

  const badge = {
    balanced: { icon: CheckCircle2, text: "الدرج متوازن", cls: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" },
    shortage: { icon: AlertTriangle, text: "عجز في الدرج", cls: "text-red-400 bg-red-500/10 border-red-500/20" },
    surplus: { icon: TrendingUp, text: "زيادة في الدرج", cls: "text-amber-400 bg-amber-500/10 border-amber-500/20" }
  }[s.differenceType];

  const Icon = badge.icon;

  return (
    <Card className="sticky top-4">
      <CardHeader>
        <CardTitle>الملخص والمطابقة النقدية</CardTitle>
        <div className={cn("flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-bold", badge.cls)}>
          <Icon className="h-3.5 w-3.5" />
          {badge.text}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <Row label="إجمالي المصاريف" value={s.totalExpenses} />
        <Row label="إجمالي أجهزة الدفع" value={s.totalPOS} />
        <div className="my-2 h-px bg-white/5" />
        <Row label="النقدية المتوقعة" value={s.expectedCash} strong />
        <Row label="النقدية الفعلية بالدرج" value={s.totalCashAvailable} strong />
        <div className="my-2 h-px bg-white/5" />
        <Row
          label="الفرق"
          value={s.difference}
          strong
          valueClassName={s.difference === 0 ? "text-emerald-400" : s.difference < 0 ? "text-red-400" : "text-amber-400"}
        />
      </CardContent>
    </Card>
  );
}

function Row({
  label,
  value,
  strong,
  valueClassName
}: {
  label: string;
  value: number;
  strong?: boolean;
  valueClassName?: string;
}) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className={cn("text-zinc-400", strong && "font-bold text-zinc-200")}>{label}</span>
      <span className={cn("num", strong ? "text-base font-extrabold" : "font-medium text-zinc-300", valueClassName)}>
        {formatMoney(value)}
      </span>
    </div>
  );
}
