import { useState } from "react";
import { Trash2 } from "lucide-react";
import type { EmployeeRecord } from "@/lib/types";
import { newId } from "@/lib/types";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface EmployeeTableProps {
  items: EmployeeRecord[];
  onChange: (items: EmployeeRecord[]) => void;
}

export function EmployeeTable({ items, onChange }: EmployeeTableProps) {
  const [name, setName] = useState("");

  function addEmployee() {
    if (!name.trim()) return;
    const record: EmployeeRecord = {
      id: newId("emp"),
      number: items.length + 1,
      name: name.trim(),
      advance: 0,
      shiftIn: "",
      shiftOut: "",
      signed: false
    };
    onChange([...items, record]);
    setName("");
  }

  function update(id: string, patch: Partial<EmployeeRecord>) {
    onChange(
      items.map((e) => {
        if (e.id !== id) return e;
        const next = { ...e, ...patch };
        if (next.hourlyRate && next.workedHours) {
          next.wageTotal = Math.round(next.hourlyRate * next.workedHours * 100) / 100;
        }
        return next;
      })
    );
  }

  function remove(id: string) {
    onChange(items.filter((e) => e.id !== id));
  }

  return (
    <div className="overflow-x-auto rounded-xl border border-white/5 bg-surface-200/40">
      <table className="w-full min-w-[720px] text-sm">
        <thead>
          <tr className="border-b border-white/5 text-xs text-zinc-500">
            <th className="p-2 text-right">#</th>
            <th className="p-2 text-right">الاسم</th>
            <th className="p-2 text-right">دخول</th>
            <th className="p-2 text-right">خروج</th>
            <th className="p-2 text-right">ساعات</th>
            <th className="p-2 text-right">أجر/ساعة</th>
            <th className="p-2 text-right">الإجمالي</th>
            <th className="p-2 text-right">سلفة</th>
            <th className="p-2 text-right">موقّع</th>
            <th className="p-2"></th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {items.map((e) => (
            <tr key={e.id}>
              <td className="num p-2 text-zinc-500">{e.number}</td>
              <td className="p-2">
                <input
                  className="h-8 w-full rounded-md bg-transparent px-1 outline-none focus:bg-surface-300/60"
                  value={e.name}
                  onChange={(ev) => update(e.id, { name: ev.target.value })}
                />
              </td>
              <td className="p-2">
                <input
                  type="time"
                  className="num h-8 w-full rounded-md bg-transparent px-1 outline-none focus:bg-surface-300/60"
                  value={e.shiftIn}
                  onChange={(ev) => update(e.id, { shiftIn: ev.target.value })}
                />
              </td>
              <td className="p-2">
                <input
                  type="time"
                  className="num h-8 w-full rounded-md bg-transparent px-1 outline-none focus:bg-surface-300/60"
                  value={e.shiftOut}
                  onChange={(ev) => update(e.id, { shiftOut: ev.target.value })}
                />
              </td>
              <td className="p-2">
                <input
                  inputMode="decimal"
                  className="num h-8 w-16 rounded-md bg-transparent px-1 outline-none focus:bg-surface-300/60"
                  value={e.workedHours ?? ""}
                  onChange={(ev) => update(e.id, { workedHours: Number(ev.target.value) || undefined })}
                />
              </td>
              <td className="p-2">
                <input
                  inputMode="decimal"
                  className="num h-8 w-16 rounded-md bg-transparent px-1 outline-none focus:bg-surface-300/60"
                  value={e.hourlyRate ?? ""}
                  onChange={(ev) => update(e.id, { hourlyRate: Number(ev.target.value) || undefined })}
                />
              </td>
              <td className="num p-2 font-bold text-accent">{e.wageTotal?.toFixed(2) ?? "-"}</td>
              <td className="p-2">
                <input
                  inputMode="decimal"
                  className="num h-8 w-16 rounded-md bg-transparent px-1 outline-none focus:bg-surface-300/60"
                  value={e.advance || ""}
                  onChange={(ev) => update(e.id, { advance: Number(ev.target.value) || 0 })}
                />
              </td>
              <td className="p-2 text-center">
                <input type="checkbox" checked={e.signed} onChange={(ev) => update(e.id, { signed: ev.target.checked })} />
              </td>
              <td className="p-2">
                <button onClick={() => remove(e.id)} type="button" className="text-zinc-500 hover:text-red-400">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="flex items-center gap-2 border-t border-dashed border-white/10 p-2">
        <Input
          value={name}
          placeholder="اسم موظف جديد"
          className="h-8 max-w-xs text-sm"
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addEmployee()}
        />
        <Button size="sm" variant="outline" onClick={addEmployee} type="button">
          إضافة موظف
        </Button>
      </div>
    </div>
  );
}
