import { useEffect, useState } from "react";
import { ClosingPage } from "@/pages/ClosingPage";
import { HistoryPage } from "@/pages/HistoryPage";
import { listReports } from "@/lib/db";
import type { DailyReport } from "@/lib/types";

type View = { name: "closing" } | { name: "history" };

export default function App() {
  const [view, setView] = useState<View>({ name: "closing" });
  const [reports, setReports] = useState<DailyReport[]>([]);
  const [openDate, setOpenDate] = useState<string | null>(null);

  useEffect(() => {
    if (view.name === "history") {
      listReports().then(setReports);
    }
  }, [view]);

  if (view.name === "history") {
    return (
      <HistoryPage
        reports={reports}
        onOpenDate={(date) => {
          setOpenDate(date);
          setView({ name: "closing" });
        }}
      />
    );
  }

  return (
    <ClosingPage
      key={openDate ?? "today"}
      initialDate={openDate ?? undefined}
      onGoHistory={() => setView({ name: "history" })}
    />
  );
}
