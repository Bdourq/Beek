import { useEffect } from "react";

interface Handlers {
  onNewRow?: () => void; // F2
  onSave?: () => void; // F4
  onSearch?: () => void; // Ctrl+K / Cmd+K
  onClear?: () => void; // Esc
}

export function useKeyboardShortcuts(handlers: Handlers) {
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      const isCtrlK = (e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k";
      if (isCtrlK) {
        e.preventDefault();
        handlers.onSearch?.();
        return;
      }
      if (e.key === "F2") {
        e.preventDefault();
        handlers.onNewRow?.();
        return;
      }
      if (e.key === "F4") {
        e.preventDefault();
        handlers.onSave?.();
        return;
      }
      if (e.key === "Escape") {
        handlers.onClear?.();
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [handlers]);
}
