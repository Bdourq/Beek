import { useCallback, useEffect, useRef, useState } from "react";
import {
  arabicDayName,
  emptyReportData,
  newId,
  todayStr,
  type DailyReport,
  type ReportData
} from "@/lib/types";
import { getReportByDate, listReports, saveReport } from "@/lib/db";

const DEFAULT_CASHIER = "قصي البدور";
const DEFAULT_BRANCH = "الفرع الرئيسي";

function blankReport(date: string): DailyReport {
  const now = new Date().toISOString();
  return {
    id: newId("report"),
    date,
    dayName: arabicDayName(date),
    cashierName: DEFAULT_CASHIER,
    branch: DEFAULT_BRANCH,
    closingType: "daily",
    status: "open",
    data: emptyReportData(),
    createdAt: now,
    updatedAt: now
  };
}

export type SaveState = "idle" | "saving" | "saved" | "error";

export function useReports(date: string) {
  const [report, setReport] = useState<DailyReport | null>(null);
  const [history, setHistory] = useState<DailyReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const refreshHistory = useCallback(async () => {
    setHistory(await listReports());
  }, []);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    (async () => {
      const existing = await getReportByDate(date);
      if (cancelled) return;
      setReport(existing ?? blankReport(date));
      await refreshHistory();
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [date, refreshHistory]);

  const persist = useCallback((next: DailyReport) => {
    setSaveState("saving");
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      try {
        await saveReport({ ...next, updatedAt: new Date().toISOString() });
        setSaveState("saved");
      } catch {
        setSaveState("error");
      }
    }, 400);
  }, []);

  /** Optimistic update: UI reflects the change instantly, disk write is debounced. */
  const updateData = useCallback(
    (patch: Partial<ReportData> | ((prev: ReportData) => Partial<ReportData>)) => {
      setReport((prev) => {
        if (!prev) return prev;
        const patchObj = typeof patch === "function" ? patch(prev.data) : patch;
        const next = { ...prev, data: { ...prev.data, ...patchObj } };
        persist(next);
        return next;
      });
    },
    [persist]
  );

  const updateMeta = useCallback(
    (patch: Partial<Pick<DailyReport, "cashierName" | "branch" | "closingType" | "status">>) => {
      setReport((prev) => {
        if (!prev) return prev;
        const next = { ...prev, ...patch };
        persist(next);
        return next;
      });
    },
    [persist]
  );

  const copyFromYesterday = useCallback(async () => {
    const y = new Date(date + "T00:00:00");
    y.setDate(y.getDate() - 1);
    const prevDate = y.toISOString().slice(0, 10);
    const prev = await getReportByDate(prevDate);
    if (!prev || !report) return false;
    const next: DailyReport = {
      ...report,
      cashierName: prev.cashierName,
      branch: prev.branch,
      data: {
        ...prev.data,
        // carry over recurring numbers, but zero out today's cash-count fields
        actualCashInDrawer: 0,
        sales: 0,
        otherSales: 0,
        openingCash: prev.data.actualCashInDrawer
      }
    };
    setReport(next);
    persist(next);
    return true;
  }, [date, report, persist]);

  const forceSaveNow = useCallback(async () => {
    if (!report) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    setSaveState("saving");
    try {
      await saveReport({ ...report, updatedAt: new Date().toISOString() });
      setSaveState("saved");
      await refreshHistory();
    } catch {
      setSaveState("error");
    }
  }, [report, refreshHistory]);

  return { report, setReport, history, loading, saveState, updateData, updateMeta, copyFromYesterday, forceSaveNow, refreshHistory };
}
