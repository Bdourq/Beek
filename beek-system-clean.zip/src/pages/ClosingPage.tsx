import { useEffect, useRef, useState } from "react";
import { useReports } from "@/hooks/useReports";
import { useKeyboardShortcuts } from "@/hooks/useKeyboardShortcuts";
import { EXPENSE_CATEGORIES, todayStr } from "@/lib/types";
import type { ExpenseCategoryKey } from "@/lib/types";
import { ExpenseTable, type ExpenseTableHandle } from "@/components/ExpenseTable";
import { EmployeeTable } from "@/components/EmployeeTable";
import { SummaryPanel } from "@/components/SummaryPanel";
import { CommandPalette } from "@/components/CommandPalette";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { exportReportToExcel, importExpensesFromExcel } from "@/lib/excel";
import { exportReportToPdf, printReport } from "@/lib/pdf";
import { Calendar, Copy, Download, FileSpreadsheet, Printer, Save, Search, Upload } from "lucide-react";

function useIsTouch() {
  const [touch, setTouch] = useState(false);
  useEffect(() => {
    setTouch(window.matchMedia("(pointer: coarse)").matches);
  }, []);
  return touch;
}

export function ClosingPage({ onGoHistory, initialDate }: { onGoHistory: () => void; initialDate?: string }) {
  const [date, setDate] = useState(initialDate ?? todayStr());
  const { report, history, saveState, updateData, updateMeta, copyFromYesterday, forceSaveNow, loading } =
    useReports(date);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const isTouch = useIsTouch();
  const importInputRef = useRef<HTMLInputElement>(null);
  const [importTarget, setImportTarget] = useState<ExpenseCategoryKey>("purchases");
  const tableRefs = useRef<Partial<Record<ExpenseCategoryKey, ExpenseTableHandle | null>>>({});
  const firstCategoryKey = EXPENSE_CATEGORIES[0].key;

  useKeyboardShortcuts({
    onNewRow: () => tableRefs.current[firstCategoryKey]?.focusNewRow(),
    onSave: () => forceSaveNow(),
    onSearch: () => setPaletteOpen(true),
    onClear: () => setPaletteOpen(false)
  });

  if (loading || !report) {
    return <div className="flex h-screen items-center justify-center text-zinc-500">جارٍ التحميل...</div>;
  }

  const saveLabel = { idle: "", saving: "جارٍ الحفظ...", saved: "تم الحفظ", error: "فشل الحفظ" }[saveState];

  return (
    <div className="mx-auto max-w-6xl p-4 pb-24">
      {/* Header */}
      <div className="no-print mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold text-zinc-50">إغلاق يحيى البايك اليومي</h1>
          <p className="text-xs text-zinc-500">
            {report.dayName} · {report.date} {saveLabel && <span className="text-accent">· {saveLabel}</span>}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-surface-300/60 px-2">
            <Calendar className="h-4 w-4 text-zinc-500" />
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="num h-9 bg-transparent text-sm text-zinc-200 outline-none"
            />
          </div>
          <Button variant="outline" size="sm" onClick={() => setPaletteOpen(true)}>
            <Search className="h-4 w-4" /> بحث (Ctrl+K)
          </Button>
          <Button variant="outline" size="sm" onClick={onGoHistory}>
            السجل
          </Button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="no-print mb-4 flex flex-wrap gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={async () => {
            const ok = await copyFromYesterday();
            if (!ok) alert("لا يوجد إغلاق مسجل ليوم أمس");
          }}
        >
          <Copy className="h-4 w-4" /> نسخ من الأمس
        </Button>
        <Button variant="outline" size="sm" onClick={() => importInputRef.current?.click()}>
          <Upload className="h-4 w-4" /> استيراد Excel
        </Button>
        <input
          ref={importInputRef}
          type="file"
          accept=".xlsx,.xls"
          className="hidden"
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            const items = await importExpensesFromExcel(file);
            if (items.length) {
              updateData((prev) => ({ [importTarget]: [...prev[importTarget], ...items] }) as any);
            }
            e.target.value = "";
          }}
        />
        <select
          value={importTarget}
          onChange={(e) => setImportTarget(e.target.value as ExpenseCategoryKey)}
          className="h-8 rounded-lg border border-white/10 bg-surface-300/60 px-2 text-xs text-zinc-300"
        >
          {EXPENSE_CATEGORIES.map((c) => (
            <option key={c.key} value={c.key}>
              استيراد إلى: {c.label}
            </option>
          ))}
        </select>
        <Button variant="outline" size="sm" onClick={() => exportReportToExcel(report)}>
          <FileSpreadsheet className="h-4 w-4" /> تصدير Excel
        </Button>
        <Button variant="outline" size="sm" onClick={() => exportReportToPdf(report)}>
          <Download className="h-4 w-4" /> تصدير PDF
        </Button>
        <Button variant="outline" size="sm" onClick={printReport}>
          <Printer className="h-4 w-4" /> طباعة (PDF عربي)
        </Button>
        <Button size="sm" onClick={forceSaveNow}>
          <Save className="h-4 w-4" /> حفظ الآن (F4)
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1fr_320px]">
        <div className="space-y-4">
          {/* Meta + cash overview */}
          <Card>
            <CardHeader>
              <CardTitle>بيانات الإغلاق</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              <Field label="الكاشير">
                <Input value={report.cashierName} onChange={(e) => updateMeta({ cashierName: e.target.value })} />
              </Field>
              <Field label="الفرع">
                <Input value={report.branch} onChange={(e) => updateMeta({ branch: e.target.value })} />
              </Field>
              <Field label="نوع الإغلاق">
                <select
                  value={report.closingType}
                  onChange={(e) => updateMeta({ closingType: e.target.value as any })}
                  className="h-10 w-full rounded-lg border border-white/10 bg-surface-300/60 px-3 text-sm text-zinc-100"
                >
                  <option value="daily">يومي</option>
                  <option value="shift">وردية</option>
                  <option value="custody">عهدة</option>
                </select>
              </Field>
              <NumField label="رصيد افتتاحي" value={report.data.openingCash} onChange={(v) => updateData({ openingCash: v })} />
              <NumField label="المبيعات" value={report.data.sales} onChange={(v) => updateData({ sales: v })} />
              <NumField label="مبيعات أخرى" value={report.data.otherSales} onChange={(v) => updateData({ otherSales: v })} />
              <NumField label="فيزا" value={report.data.visaPOS} onChange={(v) => updateData({ visaPOS: v })} />
              <NumField label="محفظة" value={report.data.walletPOS} onChange={(v) => updateData({ walletPOS: v })} />
              <NumField label="RT" value={report.data.rtPOS} onChange={(v) => updateData({ rtPOS: v })} />
              <NumField label="مايسترو" value={report.data.maestroPOS} onChange={(v) => updateData({ maestroPOS: v })} />
              <NumField
                label="ديون مسددة (قديمة)"
                value={report.data.oldDebtsPaidTotal}
                onChange={(v) => updateData({ oldDebtsPaidTotal: v })}
              />
              <NumField
                label="النقدية الفعلية بالدرج"
                value={report.data.actualCashInDrawer}
                onChange={(v) => updateData({ actualCashInDrawer: v })}
                highlight
              />
            </CardContent>
          </Card>

          {/* Expense category tables */}
          <Card>
            <CardHeader>
              <CardTitle>المصاريف (F2 لصف جديد سريع)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {EXPENSE_CATEGORIES.map((cat) => (
                <ExpenseTable
                  key={cat.key}
                  ref={(el) => (tableRefs.current[cat.key] = el)}
                  label={cat.label}
                  items={report.data[cat.key]}
                  useKeypad={isTouch}
                  onChange={(items) => updateData({ [cat.key]: items } as any)}
                />
              ))}
            </CardContent>
          </Card>

          {/* Employees */}
          <Card>
            <CardHeader>
              <CardTitle>الموظفون والورديات</CardTitle>
            </CardHeader>
            <CardContent>
              <EmployeeTable items={report.data.employees} onChange={(items) => updateData({ employees: items })} />
            </CardContent>
          </Card>

          {/* Notes */}
          <Card>
            <CardHeader>
              <CardTitle>ملاحظات عامة</CardTitle>
            </CardHeader>
            <CardContent>
              <textarea
                value={report.data.generalNotes}
                onChange={(e) => updateData({ generalNotes: e.target.value })}
                rows={4}
                className="w-full resize-none rounded-lg border border-white/10 bg-surface-300/60 p-3 text-sm text-zinc-200 outline-none focus:border-accent/60"
                placeholder="أي ملاحظات إضافية عن يوم الإغلاق..."
              />
            </CardContent>
          </Card>
        </div>

        <div>
          <SummaryPanel data={report.data} />
        </div>
      </div>

      <CommandPalette open={paletteOpen} onOpenChange={setPaletteOpen} reports={history} onSelect={setDate} />
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs text-zinc-500">{label}</span>
      {children}
    </label>
  );
}

function NumField({
  label,
  value,
  onChange,
  highlight
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  highlight?: boolean;
}) {
  return (
    <Field label={label}>
      <Input
        inputMode="decimal"
        value={value || ""}
        onChange={(e) => onChange(Number(e.target.value) || 0)}
        className={"num" + (highlight ? " border-accent/40 font-bold text-accent" : "")}
        placeholder="0.00"
      />
    </Field>
  );
}
