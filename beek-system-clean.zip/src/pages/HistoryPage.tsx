import { useMemo, useRef, useState } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import type { DailyReport } from "@/lib/types";
import { computeSummary, formatMoney } from "@/lib/calc";
import { useDebounce } from "@/hooks/useDebounce";
import { Input } from "@/components/ui/input";
import { CheckCircle2, AlertTriangle, TrendingUp, Search } from "lucide-react";

interface HistoryPageProps {
  reports: DailyReport[];
  onOpenDate: (date: string) => void;
}

export function HistoryPage({ reports, onOpenDate }: HistoryPageProps) {
  const [query, setQuery] = useState("");
  const debounced = useDebounce(query, 150);
  const parentRef = useRef<HTMLDivElement>(null);

  const filtered = useMemo(() => {
    const q = debounced.trim().toLowerCase();
    if (!q) return reports;
    return reports.filter(
      (r) => r.date.includes(q) || r.cashierName.toLowerCase().includes(q) || r.branch.toLowerCase().includes(q)
    );
  }, [debounced, reports]);

  // @tanstack/react-virtual keeps this smooth even with years of daily closings (thousands of rows)
  const virtualizer = useVirtualizer({
    count: filtered.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 68,
    overscan: 10
  });

  return (
    <div className="mx-auto max-w-3xl p-4">
      <h1 className="mb-4 text-lg font-bold">سجل الإغلاقات ({reports.length})</h1>
      <div className="mb-3 flex items-center gap-2 rounded-lg border border-white/10 bg-surface-300/60 px-3">
        <Search className="h-4 w-4 text-zinc-500" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="بحث بالتاريخ، الكاشير، الفرع..."
          className="h-11 border-none bg-transparent px-0 focus:ring-0"
        />
      </div>

      <div ref={parentRef} className="h-[70vh] overflow-y-auto rounded-xl border border-white/5">
        <div style={{ height: virtualizer.getTotalSize(), position: "relative" }}>
          {virtualizer.getVirtualItems().map((row) => {
            const r = filtered[row.index];
            const s = computeSummary(r.data);
            const badge =
              s.differenceType === "balanced"
                ? { icon: CheckCircle2, cls: "text-emerald-400" }
                : s.differenceType === "shortage"
                ? { icon: AlertTriangle, cls: "text-red-400" }
                : { icon: TrendingUp, cls: "text-amber-400" };
            const Icon = badge.icon;
            return (
              <button
                key={r.id}
                type="button"
                onClick={() => onOpenDate(r.date)}
                style={{
                  position: "absolute",
                  top: 0,
                  insetInlineStart: 0,
                  width: "100%",
                  height: row.size,
                  transform: `translateY(${row.start}px)`
                }}
                className="flex items-center justify-between border-b border-white/5 px-4 text-right hover:bg-white/5"
              >
                <div>
                  <div className="num text-sm font-bold">{r.date}</div>
                  <div className="text-xs text-zinc-500">
                    {r.dayName} · {r.cashierName} · {r.branch} · {r.status === "closed" ? "مغلق" : "مفتوح"}
                  </div>
                </div>
                <div className={"flex items-center gap-1.5 " + badge.cls}>
                  <Icon className="h-4 w-4" />
                  <span className="num text-sm font-bold">{formatMoney(s.difference)}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
