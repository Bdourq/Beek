# نظام إغلاق يحيى البايك اليومي

نظام سريع لإدارة الإغلاق اليومي والمصاريف والمطابقة النقدية — React + Vite + TypeScript + Tailwind، واجهة عربية RTL بالكامل، يعمل بدون إنترنت (IndexedDB + localStorage)، وقابل للتثبيت كتطبيق (PWA).

## النشر السريع

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/Bdourq/bekkyyy)
[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/Bdourq/bekkyyy)

## التشغيل محلياً

```bash
npm install
npm run dev
```

## البناء للإنتاج

```bash
npm run build   # ينتج مجلد dist/ الجاهز للنشر
npm run preview # لمعاينة النسخة المبنية محلياً
```

## المزايا

- **إدخال سريع**: بعد كتابة المبلغ اضغط Enter لحفظ الصف والانتقال تلقائياً لصف جديد
- **اختصارات لوحة المفاتيح**: `F2` صف جديد · `F4` حفظ · `Ctrl+K` بحث · `Esc` إغلاق
- **لوحة أرقام كبيرة** على الجوال لإدخال أسرع باللمس
- **بحث فوري** (debounce 150ms) وقائمة سجل افتراضية (virtualized) تتحمل آلاف الإغلاقات
- **نسخ من الأمس**، استيراد Excel، تصدير Excel وPDF، طباعة بتنسيق عربي RTL كامل
- **حفظ تلقائي** بدون إعادة تحميل (IndexedDB + localStorage كنسخة احتياطية)
- **PWA**: قابل للتثبيت على الجوال كتطبيق مستقل

## البنية

```
src/
  components/   مكوّنات الواجهة (جداول المصاريف، لوحة الأرقام، لوحة البحث...)
  components/ui/  مكوّنات أساسية (Button, Input, Card, Dialog)
  hooks/        منطق الحالة (التقارير، الاختصارات، الـ debounce)
  lib/          الأنواع، الحسابات، قاعدة البيانات المحلية، Excel/PDF
  pages/        شاشة الإغلاق وشاشة السجل
```

## ملاحظة مهمة حول البيانات

هذه النسخة تعمل بالكامل من طرف المتصفح (لا يوجد خادم/قاعدة بيانات مركزية) — البيانات محفوظة محلياً على كل جهاز عبر IndexedDB. إن كنت تحتاج مزامنة بين عدة أجهزة/فروع، يلزم ربطها لاحقاً بواجهة خلفية (كانت موجودة في نسخة Replit الأصلية ضمن `artifacts/api-server` و`lib/db` باستخدام Postgres + Drizzle).
