#!/usr/bin/env bash
# Force-pushes this clean project to Bdourq/bekkyyy on branch main.
# Run this from inside the extracted project folder.
set -euo pipefail

git init
git add .
git commit -m "feat: premium restaurant closing system v2 (clean rebuild)"
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/Bdourq/bekkyyy.git
git push -u origin main --force
